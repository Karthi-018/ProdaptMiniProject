function highlight(light){
	if(light=='home'){
		document.getElementById("home").style.background="snow";
	}
	else if(light=='login'){
		document.getElementById("login").style.background="snow";
	}
	else{
		document.getElementById("register").style.background="snow";
	}
}

function remove(rem){
	if(rem=='home'){
		document.getElementById("home").style.background="#2C3E50";
	}
	else if(rem=='login'){
		document.getElementById("login").style.background="#2C3E50";
	}
	else{
		document.getElementById("register").style.background="#2C3E50";
	}
	
}

function blur(){
	document.getElementById("login").value;
}