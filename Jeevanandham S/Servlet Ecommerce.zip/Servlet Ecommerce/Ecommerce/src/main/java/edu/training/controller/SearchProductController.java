package edu.training.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.training.model.Product;
import edu.training.service.ProductService;


@WebServlet("/SearchProductController")
public class SearchProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String search = request.getParameter("search");
		ProductService ps = new ProductService();
		try {
			
			List<Product> searchList = ps.searchProduct(search);
			if(searchList.size()>0) {
				request.getSession().setAttribute("product", searchList);
				request.getRequestDispatcher("viewUserProduct.jsp").forward(request, response);
			}
			else {
				response.setContentType("text/html");
				response.getWriter().println("<h3>No Products found</h3>");
				request.getRequestDispatcher("searchProduct.jsp").include(request, response);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

}
