package edu.training.model;

public class UserCart {
	
	private String userMail;
	private int pId;
	private String  pName;
	private String  pPrice;
	private int pQuantity;
	private int cQuantity;
	
	public UserCart() {
		
	}
	public UserCart(String userMail, int pId, String pName, String pPrice, int pQuantity, int cQuantity) {
		
		this.userMail = userMail;
		this.pId = pId;
		this.pName = pName;
		this.pPrice = pPrice;
		this.pQuantity = pQuantity;
		this.cQuantity = cQuantity;
	}
	public int getcQuantity() {
		return cQuantity;
	}
	public void setcQuantity(int cQuantity) {
		this.cQuantity = cQuantity;
	}
	@Override
	public String toString() {
		return "UserCart [userMail=" + userMail + ", pId=" + pId + ", pName=" + pName + ", pPrice=" + pPrice
				+ ", pQuantity=" + pQuantity + "]";
	}
	public String getUserMail() {
		return userMail;
	}
	public void setUserMail(String userMail) {
		this.userMail = userMail;
	}
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public String getpPrice() {
		return pPrice;
	}
	public void setpPrice(String pPrice) {
		this.pPrice = pPrice;
	}
	public int getpQuantity() {
		return pQuantity;
	}
	public void setpQuantity(int pQuantity) {
		this.pQuantity = pQuantity;
	}
	

}
