package edu.training.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import edu.training.model.Dao;
import edu.training.model.Product;

public class ProductService {
	
	Dao db = new Dao();
	Connection con = db.createConnection();
	PreparedStatement ps;
	
	public void addProduct(Product p) throws ClassNotFoundException, SQLException  {
		
			ps = con.prepareStatement("insert into product values(?,?,?,?,?)");
			ps.setInt(1, p.getpId());
			ps.setString(2, p.getpName());
			ps.setString(3, p.getpDesc());
			ps.setString(4, p.getpPrice());
			ps.setInt(5, p.getpQuantity());
			ps.executeUpdate();
			
	
	}
	
	
	public List<Product> viewProduct() throws SQLException, ClassNotFoundException{
		
		 
		List<Product> list = new ArrayList<>();
		ps = con.prepareStatement("select * from product");
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			list.add(new Product(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5)));
		}
		
		return list;
		
	}
	
	
	public List<Product> searchProduct(String name) throws SQLException{
		
		List<Product> search = new ArrayList<>();
		ps = con.prepareStatement("select * from product where pName like ?");
		ps.setString(1, "%"+name+"%");
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			search.add(new Product(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5)));
		}
		
		return search;
		
	}
	
	
	public void updateProduct(String price,int qty, int id) throws ClassNotFoundException, SQLException {
	
		ps = con.prepareStatement("update product set pPrice=? ,pQuantity=? where pId=?");
		ps.setString(1, price);
		ps.setInt(2, qty);
		ps.setInt(3, id);
		ps.executeUpdate();
		
	}
	
	public void deleteProduct(int id) throws SQLException {
		
		ps = con.prepareStatement("delete from product where pId=?");
		ps.setInt(1, id);
		ps.executeUpdate();
	}

	public void buyProduct(int id,int qty,int cQty) throws SQLException {
		
		qty = qty-cQty;
		ps = con.prepareStatement("update product set pQuantity = ? where pId=?");
		ps.setInt(1, qty);
		ps.setInt(2,id);
		ps.executeUpdate();
		
	}
}
