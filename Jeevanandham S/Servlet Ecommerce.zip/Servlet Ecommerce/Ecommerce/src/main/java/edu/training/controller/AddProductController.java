package edu.training.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.training.model.Product;
import edu.training.service.ProductService;

/**
 * Servlet implementation class ProductController
 */
@WebServlet("/AddProductController")
public class AddProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	
			Product p = (Product) req.getAttribute("obj");
			ProductService ps = new ProductService();
			try {
				ps.addProduct(p);
				resp.setContentType("text/html");
				resp.getWriter().write("<h1 style='color:green'>Product added successfully</h1>");
				RequestDispatcher rd = req.getRequestDispatcher("addProduct.jsp");
				rd.include(req, resp);
				
			} catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			} catch (SQLException e) {
				
				resp.setContentType("text/html");
				resp.getWriter().write("<h1 style='color:red'>Invalid Credentials</h1>");
				RequestDispatcher rd = req.getRequestDispatcher("addProduct.jsp");
				rd.include(req, resp);
				e.printStackTrace();
			}
		
	}

}
