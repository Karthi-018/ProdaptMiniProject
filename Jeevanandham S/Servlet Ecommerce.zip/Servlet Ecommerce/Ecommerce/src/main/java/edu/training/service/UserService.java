package edu.training.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import edu.training.model.Dao;
import edu.training.model.Product;
import edu.training.model.User;
import edu.training.model.UserCart;

public class UserService {
	
	
	Dao db = new Dao();
	Connection con =  db.createConnection();
	PreparedStatement ps;
	
	public void addUser(User u) throws SQLException {
		
		ps = con.prepareStatement("insert into user values(?,?,?,?,?,?,?)");
		
		ps.setString(1, u.getuName());
		ps.setString(2, u.getuNum());
		ps.setString(3, u.getuEmail());
		ps.setString(4, u.getuAddress());
		ps.setString(5, u.getuPass());
		ps.setDate(6, new java.sql.Date(u.getuDOB().getTime()));
		ps.setString(7, u.getStatus());
		ps.executeUpdate();
	}
	
	public User serachUser(String mail) throws SQLException {
		
		User user = null;
		
		ps = con.prepareStatement("select Name,Password,Status from user where Email=?");
		ps.setString(1, mail);
		ResultSet rs = ps.executeQuery();
		if(rs.next()) {
			
			 user = new User(rs.getString(1),rs.getString(2),rs.getString(3));
		}
		return user;
		
		
		
	}
	
	
	public List<User> viewUser() throws SQLException {
		
		List<User> users = new ArrayList<User>();
		ps = con.prepareStatement("select * from user");
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			users.add(new User(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getDate(6),rs.getString(7)));
		}
		return users;
	}
	
	public void approveUser(String mail) throws SQLException {
		
		ps = con.prepareStatement("update user set Status=? where Email=?");
		ps.setString(1, "Active");
		ps.setString(2, mail);
		ps.executeUpdate();
	}
	
	public void disapproveUser(String mail) throws SQLException {
		
		ps = con.prepareStatement("update user set Status=? where Email=?");
		ps.setString(1, "Inactive");
		ps.setString(2, mail);
		ps.executeUpdate();
	}
	
	public void deleteUser(String mail) throws SQLException {
		
		ps = con.prepareStatement("delete from user where Email=?");
		ps.setString(1, mail);
		ps.executeUpdate();
	}
	
	public static List<UserCart> wishList = new ArrayList<>();
	public List<UserCart> userwishList(UserCart p){
		boolean isPresent = false;
		for(UserCart i:wishList) {
			if(i.getpId()== p.getpId()) {
				isPresent = true;
				break;
			}
		}
		if(!isPresent) {
			wishList.add(p);
			System.out.println(wishList);
		}
	
		return wishList;
		
	}
	
	public void removeWishList(int id) {
		for(UserCart i:wishList) {
			if(i.getpId()==id) {
				wishList.remove(i);
				break;
			}
		}
	}
	
	public void addToCart(UserCart uc) throws SQLException {
		
		
		ps = con.prepareStatement("select Cart_Quantity from user_cart where User_mail=? and Product_Id=?");
		ps.setString(1, uc.getUserMail());
		ps.setInt(2, uc.getpId());
		ResultSet rs = ps.executeQuery();
		if(!rs.next()) {
			ps = con.prepareStatement("insert into user_cart values(?,?,?,?,?,?)");
			ps.setString(1, uc.getUserMail());
			ps.setInt(2, uc.getpId());
			ps.setString(3, uc.getpName());
			ps.setString(4, uc.getpPrice());
			ps.setInt(5, uc.getpQuantity());
			ps.setInt(6, 1);
			ps.executeUpdate();
		}
		else {
			ps = con.prepareStatement("update user_cart set Cart_Quantity = ? where User_mail=? and Product_Id=?");
			ps.setInt(1,(rs.getInt(1))+1 );
			ps.setString(2, uc.getUserMail());
			ps.setInt(3, uc.getpId());
			ps.executeUpdate();
		}
		
		
	}
	
	public String validateNumber(String mail) throws SQLException {
		
		String number = "null";
		ps = con.prepareStatement("select Phone_number from user where Email = ?");
		ps.setString(1, mail);
		ResultSet rs = ps.executeQuery();
		if(rs.next()) {
			number = rs.getString(1);
		}
		return number;
		
	}
	
	public void removeCart(int id, String mail) throws SQLException {
		
		ps = con.prepareStatement("delete from user_cart where User_mail=? and  Product_Id=?");
		ps.setString(1, mail);
		ps.setInt(2, id);
		ps.executeUpdate();
		
	}
	
	
	public List<UserCart> viewUserCart(String mail) throws SQLException {
		List<UserCart> cart = new ArrayList<>();
		System.out.println(mail);
		ps = con.prepareStatement("select * from user_cart where User_mail = ?");
		ps.setString(1, mail);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			cart.add(new UserCart(rs.getString(1),rs.getInt(2),rs.getString(3),rs.getString(4),rs.getInt(5),rs.getInt(6)));
			System.out.println(rs.getString(1));
		}
		return cart;
	}

}
