package edu.training.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.training.model.Product;
import edu.training.model.UserCart;
import edu.training.service.UserService;


@WebServlet("/UserWishListController")
public class UserWishListController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserService us = new UserService();
		List<UserCart> wishList = us.wishList;
		System.out.println(wishList);
		request.setAttribute("wishList", wishList);
		request.getRequestDispatcher("userWishList.jsp").forward(request, response);
	}

}
