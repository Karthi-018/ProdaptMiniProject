package edu.training.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.training.model.Product;

@WebFilter("/AddProductController")
public class ProductValidateFilter extends HttpFilter  {

	
	public void destroy() {
		// TODO Auto-generated method stub
	}


	public void doFilter(HttpServletRequest req, HttpServletResponse resp, FilterChain chain) throws IOException, ServletException {
		
		String id = req.getParameter("pId");
		//int id = Integer.parseInt(req.getParameter("pId"));
		String name = req.getParameter("pName");
		String desc = req.getParameter("pDesc");
		String price = req.getParameter("pPrice");
		String qty = req.getParameter("pQuantity");
		//int qty = Integer.parseInt(req.getParameter("pQuantity"));
		PrintWriter pw = resp.getWriter();
		List<String> error  = new ArrayList<>();
		boolean isValid = true;
		try {
			
		} catch (Exception e) {
			
		}
		if(id.equals("null")) {
			error.add("<h3>Id cannot be null</h3>");
			isValid = false;
		}
		
		if(name.length()<3) {
			error.add("<h3>Name must contain atleast 3 characters</h3>");
			isValid = false;
		}
		
		if(price.equals("null")) {
			error.add("<h3>Price cannot be null</h3>");
			isValid = false;
		}
		else {
			if(price.equals("0")) {
				error.add("<h3>Price cannot be 0</h3>");
				isValid = false;
			}
		}
		
		if(qty.equals("null")) {
			error.add("<h3>Quantity cannot be null</h3>");
			isValid = false;
		}
		else {
			if(qty.equals("0")) {
				error.add("<h3>Quantity cannot be 0</h3>");
				isValid = false;
			}
		}
		
		
//		if(name.length()>3) {
//			if(!price.equals("0")) {
//				if(qty>0) {
//					isValid = true;
//				}
//			}
//		}
		
		if(isValid) {
			int idInt = Integer.parseInt(id);
			int qtyInt = Integer.parseInt(qty);
			Product p = new Product(idInt,name,desc,price,qtyInt);
			req.setAttribute("obj", p);
			chain.doFilter(req, resp);
			
			
		}
		
		else {
			
			resp.setContentType("text/html");
			for(String err: error) {
				
				pw.println(err);
				
			}
			
			RequestDispatcher rd = req.getRequestDispatcher("addProduct.jsp");
			rd.include(req, resp);
			
//			resp.setContentType("text/html");
//			resp.getWriter().write("Invalid Credentials");
//			RequestDispatcher rd = req.getRequestDispatcher("addProduct.jsp");
//			rd.include(req, resp);
		}
		
		
		
		
		
		
	}
	

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
