package edu.training.model;

import java.util.Date;

public class User {
	
	private String uName;
	private String uNum;
	private String uEmail;
	private String uAddress;
	private String uPass;
	private Date uDOB;
	private String status;
	
	
	public User() {
		
	}
	
	
	
	
	
	
	
	public User(String uName, String uPass, String status) {
	
		this.uName = uName;
		this.uPass = uPass;
		this.status = status;
	}







	
	
	public String getStatus() {
		return status;
	}







	public void setStatus(String status) {
		this.status = status;
	}







	public User(String uName, String uNum, String uEmail, String uAddress, String uPass, Date uDOB, String status) {
		super();
		this.uName = uName;
		this.uNum = uNum;
		this.uEmail = uEmail;
		this.uAddress = uAddress;
		this.uPass = uPass;
		this.uDOB = uDOB;
		this.status = status;
	}







	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getuNum() {
		return uNum;
	}
	public void setuNum(String uNum) {
		this.uNum = uNum;
	}
	public String getuEmail() {
		return uEmail;
	}
	public void setuEmail(String uEmail) {
		this.uEmail = uEmail;
	}
	public String getuAddress() {
		return uAddress;
	}
	public void setuAddress(String uAddress) {
		this.uAddress = uAddress;
	}
	public String getuPass() {
		return uPass;
	}
	public void setuPass(String uPass) {
		this.uPass = uPass;
	}
	public Date getuDOB() {
		return uDOB;
	}
	public void setuDOB(Date uDOB) {
		this.uDOB = uDOB;
	}
	
	
	

}
