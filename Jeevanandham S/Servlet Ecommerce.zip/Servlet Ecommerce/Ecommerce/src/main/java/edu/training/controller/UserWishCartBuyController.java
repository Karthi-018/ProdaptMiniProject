package edu.training.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.training.model.Product;
import edu.training.model.UserCart;
import edu.training.service.ProductService;
import edu.training.service.UserService;


@WebServlet("/UserWishCartBuyController")
public class UserWishCartBuyController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String wcb = request.getParameter("option");
		String productName = request.getParameter("name");
		int productId = Integer.parseInt(request.getParameter("id"));
		String price = request.getParameter("price");
		int qty = Integer.parseInt(request.getParameter("qty"));
		String userMail = (String) request.getSession().getAttribute("userMail");
		UserCart uc = new UserCart(userMail,productId,productName,price,qty,1);
		String directTo = request.getParameter("directTo");
		UserService us = new UserService();
		ProductService ps = new ProductService();
		if(wcb.equals("WishList")) {
			
			List<UserCart> wishList = us.userwishList(uc);
			if(directTo.equals("cart")) {
				request.getRequestDispatcher("UserViewCartController").forward(request, response);
			}
			else if(directTo.equals("viewproduct")) {
				request.getRequestDispatcher("viewUserProduct.jsp").forward(request, response);
			}
			
		}
		else if(wcb.equals("movetowishlist")) {
			try {
				us.removeCart(productId, userMail);
				List<UserCart> wishList = us.userwishList(uc);
				request.getRequestDispatcher("UserViewCartController").forward(request, response);
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
		}
		else if(wcb.equals("movetocart")) {
			try {
				us.addToCart(uc);
				us.removeWishList(productId);
				if(directTo.equals("viewproduct")) {
					request.getRequestDispatcher("viewUserProduct.jsp").forward(request, response);
				}
				else if(directTo.equals("wishlist")) {
					request.getRequestDispatcher("UserWishListController").forward(request, response);
				}
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
//		else if(wcb.equals("Buy")) {
//			response.sendRedirect("buyProduct.jsp?name="+productName+"&price="+price+"&mail="+userMail+"&id="+productId+"&qty="+qty);
//			try {
//				ps.buyProduct(productId, qty);
//				response.setContentType("text/html");
//				response.getWriter().println("<h3>Product Purchased successfully</h3>");
//			} catch (SQLException e) {
//				
//				e.printStackTrace();
//			}
//		}
		
	}

}
