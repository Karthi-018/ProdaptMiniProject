package edu.training.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/OptionController")
public class OptionController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		String option = req.getParameter("option");
		HttpSession session = req.getSession();
		session.setAttribute("id",Integer.parseInt(req.getParameter("id")));
		session.setAttribute("name",req.getParameter("name"));
		
		
		if(option.equals("Edit")) {
			req.setAttribute("price", req.getParameter("price"));
			req.setAttribute("qty", Integer.parseInt(req.getParameter("qty")));
			RequestDispatcher rd = req.getRequestDispatcher("editProduct.jsp");
			rd.forward(req, resp);
		}
		else {
			
			RequestDispatcher rd = req.getRequestDispatcher("DeleteProductController");
			rd.forward(req, resp);
		}
	}

}
