package edu.training.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class EditValidateFilter
 */
@WebFilter("/EditProductServlet")
public class EditValidateFilter extends HttpFilter implements Filter {


	public void doFilter(HttpServletRequest req, HttpServletResponse resp, FilterChain chain) throws IOException, ServletException {
		
		String price = req.getParameter("pri");
		int qty = Integer.parseInt(req.getParameter("quan"));
		if(!price.equals("0")) {
			if(qty>=0) {
				req.setAttribute("price", price);
				req.setAttribute("quantity", qty);
				chain.doFilter(req, resp);
			}	
		}
		else {
			resp.setContentType("text/html");
			resp.getWriter().write("<h1 style='color:red'>Price cannot be 0</h1>");
			RequestDispatcher rd = req.getRequestDispatcher("editProduct.jsp");
			rd.include(req, resp);
		}
		
	}

	
}
