package edu.training.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.training.service.ProductService;


@WebServlet("/EditProductServlet")
public class EditProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		int id = (int) session.getAttribute("id");
		String price = (String) req.getAttribute("price");
		int qty = (int)req.getAttribute("quantity");
		ProductService ps = new ProductService();
		try {
			ps.updateProduct(price, qty, id);
//			resp.setContentType("text/html");
//			resp.getWriter().write("<h1 style='color:green'>Product added Successfully</h1>");
//			RequestDispatcher rd = req.getRequestDispatcher("ViewProductController");
//			rd.include(req, resp);
			resp.sendRedirect("ViewProductController?directTo=viewadmin");
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			resp.setContentType("text/html");
			resp.getWriter().write("<h1 style='color:red'>Invalid Credentials</h1>");
			RequestDispatcher rd = req.getRequestDispatcher("editProduct.jsp");
			rd.include(req, resp);
			e.printStackTrace();
		}
	}

}
