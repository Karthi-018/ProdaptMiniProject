package edu.training.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.training.model.Product;
import edu.training.service.ProductService;
import edu.training.service.UserService;


@WebServlet("/UserChoiceController")
public class UserChoiceController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String option = request.getParameter("submit");
		ProductService ps = new ProductService();
		if(option.equals("Home")) {
			request.getRequestDispatcher("userHomePage.jsp").forward(request, response);
		}
		else if(option.equals("View Product")) {
			
			response.sendRedirect("ViewProductController?directTo=viewuser");
			
//			try {
//				List<Product> product = ps.viewProduct();
//				request.getSession().setAttribute("product", product);
//				request.getRequestDispatcher("viewUserProduct.jsp").forward(request, response);
//			} catch (ClassNotFoundException e) {
//				
//				e.printStackTrace();
//			} catch (SQLException e) {
//				
//				e.printStackTrace();
//			}
			
		}
		else if(option.equals("Search Product")) {
			request.getRequestDispatcher("searchProduct.jsp").forward(request, response);
		}
		else if(option.equals("My List")) {
			request.getRequestDispatcher("UserWishListController").forward(request, response);
		}
		else if(option.equals("My Cart")) {
			
			request.getRequestDispatcher("UserViewCartController").forward(request, response);
			
		}
		else if(option.equals("Log out")) {
			
			UserService us = new UserService();
			us.wishList.clear();
			request.getSession().invalidate();
			request.getRequestDispatcher("login.jsp").forward(request, response);
			
		}
	}

}
