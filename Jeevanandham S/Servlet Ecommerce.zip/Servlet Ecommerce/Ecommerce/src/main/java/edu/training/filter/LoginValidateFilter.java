package edu.training.filter;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.training.model.User;
import edu.training.service.UserService;

/**
 * Servlet Filter implementation class LoginValidateFilter
 */
@WebFilter("/LoginController")
public class LoginValidateFilter extends HttpFilter implements Filter {

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}
	
	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(HttpServletRequest req, HttpServletResponse resp, FilterChain chain) throws IOException, ServletException {
		 
		UserService us = new UserService();
		String mail = req.getParameter("email");
		String pass = req.getParameter("pass");
		if(mail.equals("admin@gmail.com") && pass.equals("Reset@123")) {
			req.setAttribute("control", "admin");
			chain.doFilter(req, resp);
		}
		else {
			
			try {
				User user = us.serachUser(mail);
				if(user!=null) {
					if(pass.equals(user.getuPass())) {
						if(user.getStatus().equals("Active")) {
							resp.setContentType("text/html");
							req.getSession().setAttribute("userMail", mail);
							resp.getWriter().println("<h1>Welcome "+user.getuName()+"</h1>");
							req.getRequestDispatcher("userHomePage.jsp").include(req, resp);
						}
						else {
							resp.setContentType("text/html");
							resp.getWriter().println("<h1>Access denied</h1>");
							req.getRequestDispatcher("login.jsp").include(req, resp);
						}
						
					}
					else {
						resp.setContentType("text/html");
						resp.getWriter().println("<h1>Wrong password</h1>");
						req.getRequestDispatcher("login.jsp").include(req, resp);
					}
					
				}
				else {
					resp.setContentType("text/html");
					resp.getWriter().println("<h1>User not found</h1>");
					req.getRequestDispatcher("login.jsp").include(req, resp);
				}
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
