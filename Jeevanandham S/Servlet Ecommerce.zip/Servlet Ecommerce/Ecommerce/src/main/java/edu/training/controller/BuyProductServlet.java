package edu.training.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.training.service.ProductService;
import edu.training.service.UserService;

/**
 * Servlet implementation class BuyProductServlet
 */
@WebServlet("/BuyProductServlet")
public class BuyProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		int qty = Integer.parseInt(request.getParameter("qty"));
		int cQty = Integer.parseInt(request.getParameter("cQty"));
		String mail = request.getParameter("mail");
		String num = request.getParameter("num");
		
		ProductService ps = new ProductService();
		UserService us = new UserService();
		try {
			String number = us.validateNumber(mail);
			if(number.equals(num)) {
				ps.buyProduct(id, qty,cQty);
				us.removeCart(id,mail );
				response.setContentType("text/html");
				response.getWriter().println("<h3>Product Purchased successfully</h3>");
				request.getRequestDispatcher("userHomePage.jsp").include(request, response);
			}
			else {
				response.setContentType("text/html");
				response.getWriter().println("<h3>Wrong Phone Number</h3>");
				request.getRequestDispatcher("buyProduct.jsp").include(request, response);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
	}		

}
