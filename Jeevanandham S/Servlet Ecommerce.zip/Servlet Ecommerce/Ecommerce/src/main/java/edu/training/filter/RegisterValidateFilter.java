package edu.training.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;

import org.apache.tomcat.util.buf.StringUtils;


@WebFilter("/UserRegisterController")
public class RegisterValidateFilter extends HttpFilter implements Filter {

	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		String name = request.getParameter("name");
		List<String> error  = new ArrayList<>();
		boolean isValid = true;
		
		Date date = null;
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		String d = request.getParameter("dob");
		boolean validDate = false;
		try {
			
			if(!d.equals("null")) {
				date = df.parse(d);
				validDate = true;
			}
			
			 
		} catch (ParseException e) {
			
			error.add("<h3>Date cannot be null</h3>");
			isValid = false;
			e.printStackTrace();
		}
		
		String num = request.getParameter("phNum");
		String mail = request.getParameter("email");
		String address = request.getParameter("address");
		String pass = request.getParameter("pass");
		//String com = mail.substring(0)
		PrintWriter pw = response.getWriter();
		
		
		Pattern pattern = Pattern.compile("[a-z][a-zA-Z0-9._]+@[a-z]+[.][a-z]{2,3}");
	     Matcher match = pattern.matcher(mail);
	     
	    
	     boolean isNum = false;
	     boolean isLetter = false;
	     for(int i=0;i<pass.length();i++) {
	    	 if(Character.isDigit(pass.charAt(i))) {
	    		 isNum = true;
	    	 }
	    	 if(Character.isLetter(pass.charAt(i))) {
	    		 isLetter = true;
	    	 }
	     }
	     
	     if(isNum && isLetter) {
	    	 if(pass.length()<8 || pass.length()>15) {
	    		 error.add("<h3>Password should contain min 8 max 15 characters</h3>");
	    		 isValid = false;
	    	 }
	    	 
	     }
	     else {
	    	 error.add("<h3>Password should be alphanumeric</h3>");
	    	 isValid = false;
	     }
	        
	        
	        
	     if(match.matches()) {
	    	 if(mail.endsWith("com") || mail.endsWith("in") || mail.endsWith("org")) {
		    	 
		    	 
	    		 
	    	 }
	    	 else {
	    		 
	    		 error.add("<h3>Email should end only in com,org,in</h3>");
		    	 isValid = false;
	    		 
	    	 }
			
	    	 
	     }
	     else {
	    	 error.add("<h3>Invalid Email ID</h3>");
	    	 isValid = false;
	     }
	    
		if(name.length()<=3) {
			
			error.add("<h3>Name should contain more than 3 characters</h3>");
			isValid = false;
			
			
		}
		
		if(validDate) {
			
			if( Integer.parseInt(new SimpleDateFormat("yyyy").format(date)) >2000) {
				
				error.add("<h3>Year should be before 2000</h3>");
				isValid = false;
				
				
			}
			
		}
		
		
		if(num.length()!= 10) {
			
			error.add("<h3>Phone number must contain  10 numbers</h3>");
			isValid = false;
			
			if(!num.startsWith("9") || !num.startsWith("8") || !num.startsWith("7") || !num.startsWith("6")) {
				
				error.add("<h3>Number should start only in 9, 8, 7, 6</h3>");
				isValid = false;
				
			}
		}
		
		
		
		
		if(!isValid) {
			
			response.setContentType("text/html");
			for(String err: error) {
				
				pw.println(err);
				
			}
			
			RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
			rd.include(request, response);
		}
		
		else {
			chain.doFilter(request, response);
		}
		
		
	}

	
	public void init(FilterConfig fConfig) throws ServletException {
		
		
	}

}
