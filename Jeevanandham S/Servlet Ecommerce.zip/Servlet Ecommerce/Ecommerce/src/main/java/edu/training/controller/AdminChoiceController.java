package edu.training.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AdminChoiceController
 */
@WebServlet("/AdminChoiceController")
public class AdminChoiceController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String op = req.getParameter("adminchoice");
		
		if(op.equals("Add Product")) {
			
			RequestDispatcher rd = req.getRequestDispatcher("addProduct.jsp");
			rd.forward(req, resp);
		}
		else if(op.equals("View Product")){
			
			resp.sendRedirect("ViewProductController?directTo=viewadmin");
//			RequestDispatcher rd = req.getRequestDispatcher("ViewProductController");
//			rd.forward(req, resp);
			
		}
		else if(op.equals("View Customer")){
			
			RequestDispatcher rd = req.getRequestDispatcher("ViewCustomerController");
			rd.forward(req, resp);
		}
		else if(op.equals("log out")) {
			RequestDispatcher rd = req.getRequestDispatcher("login.jsp");
			rd.forward(req, resp);
		}
	}

}
