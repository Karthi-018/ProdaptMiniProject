package edu.training.model;

public class Product {
	
	private int pId;
	private String pName;
	private String pDesc;
	private String pPrice;
	private int pQuantity;
	
	
	
	public Product(int pId, String pName,String pPrice,int pQuantity ) {
		
		this.pId = pId;
		this.pName = pName;
		this.pPrice = pPrice;
		this.pQuantity = pQuantity;
	}


	public Product() {
		
	}
	
	
	public Product(int pId, String pName, String pDesc, String pPrice, int pQuantity) {
		
		this.pId = pId;
		this.pName = pName;
		this.pDesc = pDesc;
		this.pPrice = pPrice;
		this.pQuantity = pQuantity;
	}
	
	
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public String getpDesc() {
		return pDesc;
	}
	public void setpDesc(String pDesc) {
		this.pDesc = pDesc;
	}
	public String getpPrice() {
		return pPrice;
	}
	public void setpPrice(String pPrice) {
		this.pPrice = pPrice;
	}
	public int getpQuantity() {
		return pQuantity;
	}
	public void setpQuantity(int pQuantity) {
		this.pQuantity = pQuantity;
	}
	
	

}
