package edu.training.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Dao {
	
	Connection con;
	
	public Connection createConnection() {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/prodapt","root","hr");
		} catch (ClassNotFoundException e) {
			
		} catch (SQLException e) {
			
		}
		
		return con;
	}

}
