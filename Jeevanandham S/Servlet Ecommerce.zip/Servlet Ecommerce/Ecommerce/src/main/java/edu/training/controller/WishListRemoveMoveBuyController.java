package edu.training.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.training.service.UserService;

/**
 * Servlet implementation class WishListRemoveMoveBuyController
 */
@WebServlet("/WishListRemoveMoveBuyController")
public class WishListRemoveMoveBuyController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String option = request.getParameter("option");
		UserService us = new UserService();
		int id = Integer.parseInt(request.getParameter("id"));
		if(option.equals("remove")) {
			
			
			us.removeWishList(id);
			request.getRequestDispatcher("UserWishListController").forward(request, response);
		}
		
		else if(option.equals("move")) {
			request.getRequestDispatcher("userCart.jsp").forward(request, response);
		}
	}

}
