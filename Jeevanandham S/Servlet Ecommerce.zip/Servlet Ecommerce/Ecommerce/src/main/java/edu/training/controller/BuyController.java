package edu.training.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/BuyController")
public class BuyController extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String productName = request.getParameter("name");
		int productId = Integer.parseInt(request.getParameter("id"));
		String price = request.getParameter("price");
		int qty = Integer.parseInt(request.getParameter("qty"));
		String from = request.getParameter("from");
		int cQty;
		if(from.equals("view")) {
			cQty = 1;
			String userMail = (String) request.getSession().getAttribute("userMail");
			response.sendRedirect("buyProduct.jsp?name="+productName+"&price="+price+"&mail="+userMail+"&id="+productId+"&qty="+qty+"&cQty="+cQty);
		
		}
		else {
			cQty = Integer.parseInt(request.getParameter("cQty"));
			if(qty<cQty) {
				response.setContentType("text/html");
				response.getWriter().println("<h3>Product out of stock only "+qty+" products are available</h3>");
				request.getRequestDispatcher("userCart.jsp").include(request, response);
			}
			else {
				String userMail = (String) request.getSession().getAttribute("userMail");
				response.sendRedirect("buyProduct.jsp?name="+productName+"&price="+price+"&mail="+userMail+"&id="+productId+"&qty="+qty+"&cQty="+cQty);
			}
		}
	}
		 
		

}
