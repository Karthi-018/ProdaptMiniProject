package edu.training.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.training.model.User;
import edu.training.service.UserService;

/**
 * Servlet implementation class UserRegisterController
 */
@WebServlet("/UserRegisterController")
public class UserRegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String name = request.getParameter("name");
	String num = request.getParameter("phNum");
	String mail = request.getParameter("email");
	String address = request.getParameter("address");
	String pass = request.getParameter("pass");
	DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	Date date = null;
	try {
		 date = df.parse(request.getParameter("dob"));
	} 
	catch (ParseException e) {
		
		e.printStackTrace();
	}
	
	User u  = new User(name,num,mail,address,pass,date,"Inactive"); 
	
	UserService us = new UserService();
	try {
		us.addUser(u);
		response.setContentType("text/html");
		response.getWriter().println("");;
		request.getRequestDispatcher("login.jsp").forward(request, response);
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	
	}
	
	

}
