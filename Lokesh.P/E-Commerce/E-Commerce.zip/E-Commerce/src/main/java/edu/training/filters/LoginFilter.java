package edu.training.filters;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;

/**
 * Servlet Filter implementation class LoginFilter
 */
@WebFilter("/LoginServlet")
public class LoginFilter extends HttpFilter implements Filter {
       
	private static final Pattern emailPattern = Pattern.compile("^[a-zA-Z0-9_.]+@[a-zA-Z0-9.]+\\.(com|org|in)$");
	private static final Pattern passwordPattern = Pattern.compile("^[a-zA-Z0-9]{8,}$");
    public LoginFilter() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here

		// pass the request along the filter chain
		String mail = request.getParameter("mail");
        String password =request.getParameter("password");
        Matcher emailMatcher = emailPattern.matcher(mail);
        Matcher passwordMatcher = passwordPattern.matcher(password);
        if (emailMatcher.matches() && passwordMatcher.matches()) {
        	chain.doFilter(request, response);
        } else {
            request.getRequestDispatcher("login.jsp").forward(request, response);
            
        }
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
