package edu.training.Control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.training.Model.ProductPojo;
import edu.training.Model.cartModel;
import edu.training.Service.*;
@WebServlet("/cartController")
public class cartController extends HttpServlet {
	  cartService cartService;
	  public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException {
	        String opeartion = req.getParameter("operation");
	        cartService = new cartService();
	        HttpSession session = req.getSession();
	        if(opeartion.equals("addCart")) {
	            int cid = Integer.parseInt(session.getAttribute("cid")+"");
	            int pid = Integer.parseInt(req.getParameter("pid"));
	            try {
					cartService.addToMyCart(cid,pid);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            RequestDispatcher rd = req.getRequestDispatcher("userview.jsp");
	            rd.forward(req, res);
	        }
	        else if(opeartion.equals("viewCart")) {
	            int cid = Integer.parseInt(session.getAttribute("cid")+"");
	            List<ProductPojo> products = cartService.findProductsFromMyCart(cid);
	            session.setAttribute("products", products);
	            RequestDispatcher rd = req.getRequestDispatcher("cart.jsp");
	            rd.forward(req, res);
	        }
	        else if(opeartion.equals("removeFromCart")) {
	            int pid = Integer.parseInt(req.getParameter("pid"));
	            int cid = Integer.parseInt(session.getAttribute("cid")+"");
	            cartService.removeFromCart(cid,pid);
	            List<ProductPojo> products = cartService.findProductsFromMyCart(cid);
	            session.setAttribute("products", products);
	            RequestDispatcher rd = req.getRequestDispatcher("cart.jsp");
	            rd.forward(req, res);
	        }
	        else if(opeartion.equals("buyProduct")) {
	            int pid = Integer.parseInt(req.getParameter("pid"));
	            ProductPojo p = cartService.findProduct(pid);
	            req.setAttribute("product", p);
	            RequestDispatcher rd = req.getRequestDispatcher("payment.jsp");
	            rd.forward(req, res);
	        }
	        else if(opeartion.equals("logout")) {
	            session.invalidate();
	            res.sendRedirect("home.jsp");
	        }
}
}
