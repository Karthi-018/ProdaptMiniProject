package edu.training.Control;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.training.Model.ProductPojo;
import edu.training.Service.CartDAO;

/**
 * Servlet implementation class wishlistController
 */
@WebServlet("/wishlistController")
public class wishlistController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CartDAO cartDAO = new CartDAO();
		String operation = request.getParameter("operation");
		HttpSession session=request.getSession();
		if(operation.equals("addFav")){
            int pid = Integer.parseInt(request.getParameter("pid"));
            System.out.println(pid);
            ArrayList<ProductPojo> fav = (ArrayList<ProductPojo>)session.getAttribute("fav");
            boolean exist = false;
            for(ProductPojo p : fav) {
                if(p.getProduct_id()==pid) {
                    exist = true;
                    break;
                }
            }
            if(!exist) {
                ProductPojo p = cartDAO.findProduct(pid);
                fav.add(p);
                System.out.println(fav);
            }
            session.setAttribute("fav", fav);
            System.out.println(session.getAttribute("fav"));
            RequestDispatcher rd = request.getRequestDispatcher("userview.jsp");
            rd.forward(request, response);
        }
		else if(operation.equals("viewFav")) {
            RequestDispatcher rd = request.getRequestDispatcher("wishlist.jsp");
            rd.forward(request, response);
        }
        else if(operation.equals("removeFromFav")) {
            int id = Integer.parseInt(request.getParameter("pid"));
            List<ProductPojo> fav = (ArrayList<ProductPojo>)session.getAttribute("fav");
            List<ProductPojo> newFav = new ArrayList<ProductPojo>();
            for(ProductPojo p : fav) {
                if(p.getProduct_id()!=id) newFav.add(p);
            }
            session.setAttribute("fav", newFav);
            RequestDispatcher rd = request.getRequestDispatcher("wishlist.jsp");
            rd.forward(request, response);
        }
	}
    

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
