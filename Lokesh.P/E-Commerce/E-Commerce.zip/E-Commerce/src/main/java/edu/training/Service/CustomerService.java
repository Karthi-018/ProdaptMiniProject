package edu.training.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import edu.training.Model.ProductPojo;

public class CustomerService {

public List<ProductPojo> custsearch(String name) throws SQLException {

    Connection con =DAOClass.getConnect();

    PreparedStatement ps =con.prepareStatement("select * from product where Product_Name=?");

    ps.setString(1, name);

    ResultSet rs=ps.executeQuery();

    List<ProductPojo> prolist=new ArrayList<>();

    while(rs.next()) {

        prolist.add(new ProductPojo(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5)));

    }

    System.out.println(prolist);

    

    return prolist;  

}

}