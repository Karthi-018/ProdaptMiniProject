package edu.training.Control;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.training.Model.Customer;
import edu.training.Model.ProductPojo;
import edu.training.Service.AdminService;

/**
 * Servlet implementation class AdminController
 */
@WebServlet("/AdminController")
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	AdminService adminService;

    HttpSession session;

    public void init() {
        adminService = new AdminService();
    }
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String operation = request.getParameter("operation");
		if(operation.equals("approve")) {
            List<Customer> customers = adminService.findToBeApproved();
            System.out.println(customers);
            HttpSession session = request.getSession(); // Obtain the session
            session.setAttribute("customers", customers);
            RequestDispatcher rd1 = request.getRequestDispatcher("toBeApproved.jsp");
            rd1.forward(request, response);
            
        }
        else if(operation.equals("approveCustomer")) {
            int id = Integer.parseInt(request.getParameter("id"));
            System.out.println(id);
            if(adminService.approve(id)) {
                List<Customer> customers = adminService.findToBeApproved();
                HttpSession session = request.getSession();
                session.setAttribute("customers", customers);
                RequestDispatcher rd = request.getRequestDispatcher("toBeApproved.jsp");
                rd.forward(request, response);
            }
        }
        else if(operation.equals("deleteCustomer")) {
            int id = Integer.parseInt(request.getParameter("id"));
            if(adminService.deleteCustomer(id)) {
                List<Customer> customers = adminService.findToBeApproved();
                session.setAttribute("customers", customers);
                RequestDispatcher rd = request.getRequestDispatcher("toBeApproved.jsp");
                rd.forward(request, response);
            }
        }
        else if(operation.equals("manage")) {
            List<Customer> customers = adminService.findAllCustomers();
            HttpSession session=request.getSession();
            session.setAttribute("customers", customers);
            RequestDispatcher rd = request.getRequestDispatcher("manage.jsp");
            rd.forward(request, response);
        }
        else if(operation.equals("deleteRealCustomer")) {
            int id = Integer.parseInt(request.getParameter("id"));
            if(adminService.deleteCustomer(id)) {
                List<Customer> customers = adminService.findAllCustomers();
                HttpSession session=request.getSession();
                session.setAttribute("customers", customers);
                RequestDispatcher rd = request.getRequestDispatcher("manage.jsp");
                rd.forward(request, response);
            }
        }
        
     
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
