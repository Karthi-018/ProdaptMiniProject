package edu.training.Service;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import edu.training.Model.ProductPojo;
import edu.training.Model.cartModel;

public class CartDAO {
	public void addToMyCart(int cid, int pid,int quantity) {
        Connection con = DAOClass.getConnect();

        try {
            boolean exist = false;
            PreparedStatement s = con.prepareStatement("SELECT * FROM cart WHERE customer_id=? AND product_id=? AND quantity=?;");
            s.setInt(1, cid);
            s.setInt(2, pid);
            s.setInt(3, quantity);
            ResultSet rs = s.executeQuery();
            if(rs.next()) {
                exist = true;
                System.out.println("hello");
            }
            if(!exist) {
                PreparedStatement ps = con.prepareStatement("INSERT INTO cart VALUES (?,?,?);");

                ps.setInt(1, cid);
                ps.setInt(2, pid);
                ps.setInt(3,quantity);

                int result = ps.executeUpdate();
            }

        }
        catch(SQLException e) {
            System.out.println("Unsuccessful adding cutomer");
        }
    }
	public void updateQuantityInCart(int cid, int pid, int quantity) {
        Connection con = DAOClass.getConnect();

        try {
            PreparedStatement ps = con.prepareStatement("UPDATE cart SET quantity = ? WHERE customer_id = ? AND product_id = ?;");
            ps.setInt(1, quantity);
            ps.setInt(2, cid);
            ps.setInt(3, pid);
            int result = ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Unsuccessful updating quantity in cart");
        }
    }
	public ProductPojo findProduct(int pid) {
        Connection con = DAOClass.getConnect();

 

        try {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM product WHERE Product_id=?;");
            ps.setInt(1,pid);
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                return new ProductPojo(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5));
            }
            return null;
        } catch (SQLException e) {
            System.out.println("Unsuccessful all customer");
            return null;
        }
    }

 

    public List<ProductPojo> findProductsFromMyCart(int cid) {
        Connection con = DAOClass.getConnect();
        System.out.println(1);
        try {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM cart WHERE customer_id=?;");
            ps.setInt(1,cid);
            ResultSet rs = ps.executeQuery();
            List<Integer> list = new ArrayList<Integer>();
            while(rs.next()) {
                list.add(rs.getInt(2));
                list.add(rs.getInt(3));
            }
            System.out.println(list);
            List<ProductPojo> products = new ArrayList<ProductPojo>();
            for(int i : list) {
                products.add(findProduct(i));
            }
            return products;
        } catch (SQLException e) {
            System.out.println("Unsuccessful all customer");
            return null;
        }
    }

 

    public void removeFromCart(int cid, int pid,int quantity) {

        Connection con =DAOClass.getConnect();
        System.out.println("delete");

 

        try {
            PreparedStatement ps = con.prepareStatement("UPDATE cart SET quantity = quantity - ? WHERE customer_id = ? AND product_id = ?;");
            ps.setInt(1, cid);
            ps.setInt(2, pid);
            ps.setInt(3, quantity);
            int result = ps.executeUpdate();
            if (result > 0) {
                System.out.println("Removed " + quantity + " items from the cart.");
            } else {
                System.out.println("Failed to remove items from the cart.");
            }
        } catch (SQLException e) {
            System.out.println("Unsuccessful delete customer");
        }

    }
}
