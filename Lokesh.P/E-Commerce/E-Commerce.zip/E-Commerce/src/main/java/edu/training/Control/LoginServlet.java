package edu.training.Control;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.training.Model.Customer;
import edu.training.Model.ProductPojo;
import edu.training.Service.AdminService;
import edu.training.Service.DAOClass;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	AdminService adminService=new AdminService();
    	String operation = request.getParameter("login");
    	if(operation.equals("login")) {
            String email = request.getParameter("mail");
            String password = request.getParameter("password");
            String role = getRole(email,password);
            if(role.equals("admin")) {
                HttpSession session = request.getSession();
                session.setAttribute("role",role);
                session.setAttribute("mail", email);
                List<ProductPojo> products = adminService.findAll();
                session.setAttribute("products", products);
                RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
                rd.forward(request, response);
            }
            else if(role.equals("customer")) {
                HttpSession session = request.getSession();
                session.setAttribute("role",role);
                int id = adminService.findCustomerId(email,password);
                session.setAttribute("cid", id);
                List<ProductPojo> products = adminService.findAll();
                session.setAttribute("products", products);
                session.setAttribute("fav",new ArrayList<ProductPojo>());
                RequestDispatcher rd = request.getRequestDispatcher("user.jsp");
                
                rd.forward(request, response);
            }
            else {
                RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
                rd.forward(request, response);
            }
    	
       /* String email = request.getParameter("mail");
        String password = request.getParameter("password");
        System.out.println(email);
        System.out.println(password);
        // Assuming you have a method getRole() to determine the user's role
        String role = getRole(email, password);
        System.out.println(role);*/

        if ("admin".equals(role)) {
            // Redirect to the admin page
        	System.out.println("hi");
        	request.getRequestDispatcher("AllUserDetails").forward(request, response);
			/* response.sendRedirect("AllUserDetails"); */
        } else if ("customer".equals(role)) {
            // Redirect to the customer page
        	System.out.println("customer");
        	request.getRequestDispatcher("userview.jsp").forward(request, response); // Replace with the actual customer page URL
        } 
        else {
            // Handle non-users or errors
        	request.setAttribute("errorMessage", "Your account has been deactivated.");
        	request.getRequestDispatcher("errorPage.jsp").forward(request, response);

			/* response.sendRedirect("errorPage.jsp"); */ // Replace with the actual error page URL
            return; 
        }
    	}
    }

	public String getRole(String email, String password) {
		try {
            Connection con = DAOClass.getConnect();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM customers WHERE Mail=? AND Password = ? AND approve=true;");
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                if(rs.getBoolean(7)) {
                    return "admin";
                }
                else {
                    return "customer";
                }
            }
            return "nonuser";
        }
        catch(SQLException e) {
            return "error loggging in";
        }
    }
}

