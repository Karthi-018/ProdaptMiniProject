package edu.training.filters;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;

/**
 * Servlet Filter implementation class RegisterationFilter
 */
@WebFilter("/register")
public class RegisterationFilter extends HttpFilter implements Filter {
    
	
	private static final Pattern namePattern = Pattern.compile("^[a-zA-Z]{3,}$");
	private static final Pattern phonePattern = Pattern.compile("^[9786][0-9]{9}$");
	private static final Pattern emailPattern = Pattern.compile("^[a-zA-Z0-9_.]+@[a-zA-Z0-9.]+\\.(com|org|in)$");
	private static final Pattern passwordPattern = Pattern.compile("^[a-zA-Z0-9]{8,}$");

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		 	int id =Integer.parseInt(request.getParameter("id"));
			String name1 = request.getParameter("name1");
	        String dob = request.getParameter("dob");
	        String phone = request.getParameter("phone");
	        String mail = request.getParameter("email");
	        String password =request.getParameter("password");
	        Matcher nameMatcher = namePattern.matcher(name1);
	        Matcher phoneMatcher = phonePattern.matcher(phone);
	        Matcher emailMatcher = emailPattern.matcher(mail);
	        Matcher passwordMatcher = passwordPattern.matcher(password);
			/*
			 * boolean isValid = validateInput(name1, dob, phone, mail, password); if
			 * (!isValid) { // If validation fails, you can choose to display an error
			 * message on the same page request.setAttribute("registrationError",
			 * "Registration failed due to invalid data.");
			 * request.getRequestDispatcher("register.jsp").include(request, response);
			 * return; }
			 * 
			 */
	        if (!nameMatcher.matches()) {
	            request.setAttribute("nameError", "The name must be more than 3 characters long.");
	        }
	       if (!phoneMatcher.matches()) {
	            request.setAttribute("phoneError", "The phone number must start with 9, 8, 7, or 6.");
	            
	        }
	        if (!emailMatcher.matches()) {
	            request.setAttribute("emailError", "The email address must end with .com, .org, or .in.");
	        }
	        if (!passwordMatcher.matches()) {
	            request.setAttribute("passwordError", "The password must be alphanumeric and at least 8 characters long.");
	        }

	        if (nameMatcher.matches() && phoneMatcher.matches() && emailMatcher.matches() && passwordMatcher.matches()) {
	        	request.getRequestDispatcher("/RegisterLoginControl").forward(request, response);
				/*
				 * RequestDispatcher rd=request.getRequestDispatcher("RegisterLoginControl");
				 * rd.forward(request, response);
				 */
	            
	        	chain.doFilter(request, response);
	        } else {
	            request.getRequestDispatcher("register.jsp").forward(request, response);
	            
	        }
	}

	/*
	 * private boolean validateInput(String name1, String dob, String phone, String
	 * email, String password) { boolean isValid = true;
	 * 
	 * if (name1.length()<3) { request.setAttribute("nameError",
	 * "The name must be more than 3 characters long."); }
	 * 
	 * return isValid; }
	 */

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}
	public void destroy() {
		// TODO Auto-generated method stub
	}
}
