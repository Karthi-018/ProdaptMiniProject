package edu.training.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import edu.training.Model.Customer;
import edu.training.Service.DAOClass;

 

public class Admin_Register_Service 
{
	public void insertUser(Customer customer) throws SQLException
	{
		try {
		Connection con=DAOClass.getConnect();
		PreparedStatement ps = con.prepareStatement("INSERT INTO customers VALUES (?,?,?,?,?,?,?,?)");
		 ps.setInt(1, customer.getId());
		 ps.setString(2, customer.getName());
		 ps.setString(3, customer.getPhone());
		 ps.setString(4, customer.getDob());
		 ps.setString(5, customer.getEmail());
		 ps.setString(6, customer.getPassword());
		 ps.setBoolean(7,false);
         ps.setBoolean(8,false);
	     ps.executeUpdate();
	     System.out.println("success");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

  
}