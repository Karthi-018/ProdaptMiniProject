package edu.training.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import edu.training.Model.ProductPojo;
import edu.training.Model.cartModel;

public class cartService {

	public void addToMyCart(int cid, int pid) throws SQLException {
        Connection con =DAOClass.getConnect();
        System.out.println(cid);
        System.out.println(pid);
        try {
            PreparedStatement s = con.prepareStatement("SELECT * FROM cart WHERE customer_id=? AND product_id=?;");
            s.setInt(1, cid);
            s.setInt(2, pid);
            ResultSet rs = s.executeQuery();
            rs.next();
            int quantity=rs.getInt(3);
            PreparedStatement ps =con.prepareStatement("update cart set quantity=?  where customer_id=? and product_id=?");
            quantity++;
            ps.setInt(1, quantity);
            ps.setInt(2, cid);
            ps.setInt(3, pid);
            ps.executeUpdate();
            
			/*
			 * if(rs.next()) { exist = true; } if(!exist) { PreparedStatement ps =
			 * con.prepareStatement("INSERT INTO carts VALUES (?,?);");
			 * 
			 * ps.setInt(1, cid); ps.setInt(2, pid);
			 * 
			 * int result = ps.executeUpdate(); }
			 */

        }
        catch(SQLException e) {
        	System.out.println(e.getMessage());
            System.out.println("Unsuccessful adding cutomer");
            PreparedStatement ps =con.prepareStatement("insert into cart values(?,?,?);");
            ps.setInt(1, cid);
            ps.setInt(2, pid);
            ps.setInt(3, 1);
            ps.executeUpdate();
            
        }
    }

 

    public List<ProductPojo> findProductsFromMyCart(int cid) {
        Connection con = DAOClass.getConnect();
        System.out.println(1);
        try {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM cart WHERE customer_id=?;");
            System.out.println(2);
            System.out.println(cid);
            ps.setInt(1,cid);
            ResultSet rs = ps.executeQuery();
            System.out.println(3);
            List<Integer> list = new ArrayList<Integer>();
            while(rs.next()) {
                list.add(rs.getInt(2));
            }
            System.out.println(list);
            List<ProductPojo> products = new ArrayList<ProductPojo>();
            for(int i : list) {
                products.add(findProduct(i));
            }
            return products;
        } catch (SQLException e) {
            System.out.println("Unsuccessful all customer");
            return null;
        }
    }
    public ProductPojo findProduct(int pid) {
        Connection con = DAOClass.getConnect();

 

        try {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM product WHERE Product_id=?;");
            ps.setInt(1,pid);
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                return new ProductPojo(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5));
            }
            return null;
        } catch (SQLException e) {
            System.out.println("Unsuccessful all customer");
            return null;
        }
    }

 

    public void removeFromCart(int cid, int pid) {

        Connection con =DAOClass.getConnect();
        System.out.println("delete");

 

        try {
            PreparedStatement ps = con.prepareStatement("DELETE FROM cart WHERE customer_id=? AND product_id=?;");
            ps.setInt(1, cid);
            ps.setInt(2, pid);
            int result = ps.executeUpdate();
            System.out.println("delete");
        } catch (SQLException e) {
            System.out.println("Unsuccessful delete customer");
        }

    }
}
