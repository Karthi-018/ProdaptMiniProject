package edu.training.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import edu.training.Model.Customer;
import edu.training.Model.ProductPojo;

public class AdminService {

	public List<Customer> findToBeApproved() {
        Connection con = DAOClass.getConnect();
        System.out.println("to be approve");

 

        try {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM customers WHERE approve=false;");
            ResultSet rs = ps.executeQuery();
            ArrayList<Customer> customers = new ArrayList<>();
            while(rs.next()) {
                customers.add(new Customer(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6)));
                System.out.println(customers);
            }
            return customers;
        } catch (SQLException e) {
            System.out.println("Unsuccessful approve customer");
            return null;
        }
    }
	public List<ProductPojo> findAll() {
        try {
            List<ProductPojo> products = new ArrayList<ProductPojo>() ;
            Connection con =DAOClass.getConnect();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM product");
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                products.add(new ProductPojo(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5)));
            }
            System.out.println(products);
            return products;
        }
        catch(SQLException e) {
            return null;
        }
    }
 

    public boolean approve(int id) {
        Connection con =DAOClass.getConnect();
        System.out.println("update");

 

        try {
            PreparedStatement ps = con.prepareStatement("UPDATE customers SET approve=? WHERE Id=?;");
            ps.setBoolean(1, true);
            ps.setInt(2, id);

            int result = ps.executeUpdate();
            System.out.println("update");

 

            return true;
        } catch (SQLException e) {
            System.out.println("Unsuccessful UPDATE customer");
            return false;
        }
    }

 

    public boolean deleteCustomer(int id) {
        Connection con = DAOClass.getConnect();
        System.out.println("delete");

 

        try {
            PreparedStatement ps = con.prepareStatement("DELETE FROM customers WHERE Id=?;");
            ps.setInt(1, id);

            int result = ps.executeUpdate();
            System.out.println("delete");

 

            return true;
        } catch (SQLException e) {
            System.out.println("Unsuccessful delete customer");
            return false;
        }
    }

 

    public List<Customer> findAllCustomers() {
        Connection con = DAOClass.getConnect();
        System.out.println("all cus");

 

        try {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM customers WHERE is_approved=false AND approve=true;");
            ResultSet rs = ps.executeQuery();
            ArrayList<Customer> customers = new ArrayList<>();
            while(rs.next()) {
                customers.add(new Customer(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6)));
            }
            return customers;
        } catch (SQLException e) {
            System.out.println("Unsuccessful all customer");
            return null;
        }
    }

 

    public int findCustomerId(String email, String password) {

        Connection con =DAOClass.getConnect();

        try {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM customers WHERE Mail=? AND Password=?;");
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                return rs.getInt(1);
            }
            return -1;
        } catch (SQLException e) {
            System.out.println("Unsuccessful all customer");
            return -1;
        }
    }
    public ProductPojo findProduct(int pid) {
        Connection con =DAOClass.getConnect();

 

        try {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM product WHERE Product_id=?;");
            ps.setInt(1,pid);
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                return new ProductPojo(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5));
            }
            return null;
        } catch (SQLException e) {
            System.out.println("Unsuccessful all customer");
            return null;
        }
    }

}
